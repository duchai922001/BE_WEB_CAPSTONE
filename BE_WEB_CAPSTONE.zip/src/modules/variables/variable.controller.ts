import {
  Body,
  Controller,
  Get,
  HttpStatus,
  Param,
  Patch,
  Post,
} from '@nestjs/common';
import { CreateVariableDto } from './dtos/create.dto';
import { VariableService } from './variable.service';
import { createResponse } from 'src/common/helpers/response.helper';
import { ResponseMessage } from 'src/common/enums/responseMessage';
import { UpdateVariableDto } from './dtos/update.dto';

@Controller('variables')
export class VariableController {
  constructor(private readonly variableService: VariableService) {}
  @Post('')
  async create(@Body() dto: CreateVariableDto) {
    const data = await this.variableService.create(dto);
    return createResponse(HttpStatus.CREATED, data, ResponseMessage.CREATE);
  }
  @Get('product/:id')
  async findVariableByProductId(@Param('id') id: string) {
    const data = await this.variableService.findByProductId(id);
    return createResponse(HttpStatus.OK, data, ResponseMessage.GET);
  }
  @Get(':id')
  async findById(@Param('id') id: string) {
    const data = await this.variableService.findById(id);
    return createResponse(HttpStatus.OK, data, ResponseMessage.GET);
  }

  @Patch(':id')
  async updateVariable(
    @Param('id') id: string,
    @Body() updateData: UpdateVariableDto,
  ) {
    return this.variableService.updateFields(id, updateData);
  }
}
