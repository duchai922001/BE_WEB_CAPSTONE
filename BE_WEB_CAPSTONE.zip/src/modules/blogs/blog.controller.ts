import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  HttpStatus,
  Query,
  UseGuards,
  Request,
} from '@nestjs/common';
import { BlogService } from './blog.service';
import { CreateBlogDto } from './dtos/create.dto';
import { createResponse } from 'src/common/helpers/response.helper';
import { ResponseMessage } from 'src/common/enums/responseMessage';
import { BaseQueryDto } from 'src/common/dtos/base-query.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@Controller('blogs')
export class BlogController {
  constructor(private readonly blogService: BlogService) {}

  @UseGuards(JwtAuthGuard)
  @Post()
  async create(@Body() dto: CreateBlogDto, @Request() req) {
    const userId = req.user.userId;
    const blog = await this.blogService.createBlog(dto, userId);
    return createResponse(HttpStatus.CREATED, blog, ResponseMessage.CREATE);
  }

  @Get('latest')
  async getLatestBlog() {
    const blog = await this.blogService.getLatestBlog();
    return createResponse(HttpStatus.OK, blog, ResponseMessage.GET);
  }

  @Put(':id')
  async update(@Param('id') id: string, @Body() dto: Partial<CreateBlogDto>) {
    const updated = await this.blogService.updateBlog(id, dto);
    return createResponse(HttpStatus.OK, updated, ResponseMessage.UPDATE);
  }

  @Delete(':id')
  async delete(@Param('id') id: string) {
    await this.blogService.deleteBlog(id);
    return createResponse(HttpStatus.OK, null, ResponseMessage.DELETE);
  }

  @Get(':id')
  async getById(@Param('id') id: string) {
    const blog = await this.blogService.findBlogById(id);
    return createResponse(HttpStatus.OK, blog, ResponseMessage.GET);
  }

  @Get()
  async getAll(@Query() query: BaseQueryDto) {
    const blogs = await this.blogService.getBlogsQuery(query);
    return createResponse(HttpStatus.OK, blogs, ResponseMessage.GET);
  }
}
