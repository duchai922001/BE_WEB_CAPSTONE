import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';
import { InstalmentRequestStatus } from 'src/common/enums/instalmentRequest';

export type InstalmentRequestDocument = InstalmentRequest & Document;

@Schema({ timestamps: true, versionKey: false })
export class InstalmentRequest {
  @Prop({ type: Types.ObjectId, ref: 'User', required: true })
  userId: Types.ObjectId;

  @Prop({ type: Types.ObjectId, ref: 'Product', required: true })
  productId: Types.ObjectId;

  @Prop({ type: Types.ObjectId, ref: 'Variable' })
  variableId: Types.ObjectId;

  @Prop({ type: Types.ObjectId, ref: 'User' })
  assignedStaffId: Types.ObjectId;

  @Prop({ type: String, required: true })
  instalmentRequestOrder: string;

  @Prop({ type: Date, required: true })
  appointmentDate: Date;

  @Prop({ type: String, required: true })
  bankName: string;

  @Prop({ type: Number, required: true })
  installmentPeriod: number;

  @Prop({ type: String })
  note?: string;

  @Prop({
    type: String,
    enum: InstalmentRequestStatus,
    default: InstalmentRequestStatus.PENDING,
  })
  status: InstalmentRequestStatus;

  @Prop({ type: String, required: true })
  documentNumber: string;

  @Prop({ type: String, required: true })
  idFrontUrl: string;

  @Prop({ type: String, required: true })
  idBackUrl: string;

  // ảnh giấy phép lái xe
  @Prop({ type: String })
  driverLicenseFrontUrl?: string;

  @Prop({ type: String })
  driverLicenseBackUrl?: string;

  // ảnh bảo hiểm y tế
  @Prop({ type: String })
  healthInsuranceUrl?: string;

  @Prop({ type: String })
  insurance?: string;

  @Prop({ type: Number, required: true })
  income: number;

  @Prop({ type: String, required: true })
  occupation: string;

  @Prop({ type: String, required: true })
  fullName: string;

  @Prop({ type: String, required: true })
  phone: string;

  @Prop({ type: String, required: true })
  address: string;

  @Prop({ type: String })
  resultImage: string;
}

export const InstalmentRequestSchema =
  SchemaFactory.createForClass(InstalmentRequest);
