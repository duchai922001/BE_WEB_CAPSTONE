import {
  Controller,
  Post,
  Get,
  Delete,
  Param,
  Body,
  HttpStatus,
  Put,
  UseGuards,
  Request,
} from '@nestjs/common';
import { FeedbackService } from './feedback.service';
import { CreateFeedbackDto } from './dtos/create.feedback';
import { UpdateFeedbackDto } from './dtos/update.feedback';
import { createResponse } from 'src/common/helpers/response.helper';
import { ResponseMessage } from 'src/common/enums/responseMessage';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@Controller('feedbacks')
export class FeedbackController {
  constructor(private readonly feedbackService: FeedbackService) {}

  @Post()
  async create(@Body() dto: CreateFeedbackDto) {
    const data = await this.feedbackService.create(dto);
    return createResponse(HttpStatus.CREATED, data, ResponseMessage.CREATE);
  }

  @Get('order/:orderId')
  async getFeedbackByOrder(@Param('orderId') orderId: string) {
    const data = await this.feedbackService.getFeedbackByOrderId(orderId);
    return createResponse(HttpStatus.CREATED, data, ResponseMessage.GET);
  }

  @UseGuards(JwtAuthGuard)
  @Get('user-product/:productId')
  async findByProductAndUser(
    @Param('productId') productId: string,
    @Request() req,
  ) {
    const userId = req.user?.userId;
    const data = await this.feedbackService.findByProductAndUser(
      productId,
      userId,
    );
    return createResponse(HttpStatus.CREATED, data, ResponseMessage.GET);
  }

  @Get()
  async findAll() {
    const data = await this.feedbackService.findAll();
    return createResponse(HttpStatus.OK, data, ResponseMessage.GET);
  }

  @Get('product/:productId')
  async getFeedbackByProduct(@Param('productId') productId: string) {
    const data = await this.feedbackService.getFeedbackByProduct(productId);
    return createResponse(HttpStatus.OK, data, ResponseMessage.GET);
  }

  @Get(':id')
  async findById(@Param('id') id: string) {
    const data = await this.feedbackService.findById(id);
    return createResponse(HttpStatus.CREATED, data, ResponseMessage.GET);
  }

  @Put(':id')
  async update(@Param('id') id: string, @Body() dto: UpdateFeedbackDto) {
    const data = await this.feedbackService.update(id, dto);
    return createResponse(HttpStatus.CREATED, data, ResponseMessage.UPDATE);
  }

  @Delete(':id')
  async delete(@Param('id') id: string) {
    const data = await this.feedbackService.delete(id);
    return createResponse(HttpStatus.CREATED, data, ResponseMessage.DELETE);
  }
}
